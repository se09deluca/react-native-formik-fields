import {StyleSheet} from 'react-native';
import Style from "../style";

const styles = StyleSheet.create({
    pickerContainer: {
        alignSelf: 'stretch',
        minHeight: Platform.OS === "android" ? 82 : 90
    },
    pickerLabel: {
        fontFamily: Style.fontFamilyName,
        fontSize: 16,
        fontWeight: "bold",
        fontStyle: "normal",
        lineHeight: 20,
        letterSpacing: 0,
        color: Style.TEXT,
        paddingLeft: 20
    },
    required: {
        fontFamily: Style.fontFamilyName,
        fontSize: 16,
        fontWeight: "bold",
        fontStyle: "normal",
        lineHeight: 20,
        letterSpacing: 0,
        color: Style.PRIMARY
    },
    errorLabel: {
        fontFamily: Style.fontFamilyName,
        fontSize: 12,
        fontWeight: "normal",
        fontStyle: "normal",
        lineHeight: 16,
        letterSpacing: 0,
        textAlign: "right",
        color: Style.ERROR
    }
});

export default styles;
