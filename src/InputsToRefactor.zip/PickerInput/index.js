import React, {useState} from 'react';
import {Image, Picker, Platform, Text, TextInput, View} from 'react-native';
import styles from './styles';
import PropTypes from 'prop-types';
import IOSPicker from "react-native-ios-picker";
import Style from "../style";

export function PickerInput({
                                field: {
                                    name,
                                    onBlur,
                                    onChange,
                                    value,
                                },
                                form: {
                                    errors,
                                    touched,
                                    status = {},
                                    setStatus
                                },
                                label,
                                prompt = "",
                                isRequired = false,
                                setFieldValue,
                                disabled = false,
                                androidPickerMode = 'dialog',
                                options = []
                            }) {

    const [ onFocus, setOnFocus ] = useState(false);

    return (
        <View style={[ styles.pickerContainer ]}>

            <Text style={styles.pickerLabel}>{label}&nbsp;{ isRequired? <Text style={styles.required}>*</Text>: null }</Text>

            { disabled ?
                <TextInput
                    style={[
                        {
                            height: 50,
                            borderRadius: 25,
                            borderStyle: "solid",
                            borderWidth: (errors[name] && touched[name]) || status.failed ? 1: 0.5,
                            borderTopWidth: (errors[name] && touched[name]) || status.failed ? 1.15: 0.5,
                            borderColor: (errors[name] && touched[name]) || status.failed ?"#ef6a6e": "rgba(83, 100, 104, 0.3)",
                            paddingHorizontal: 20,
                            color: disabled ? 'gray' : TEXT },
                        (errors[name] && touched[name]) ?
                            {
                                borderWidth: 1,
                                borderColor: "#ef6a6e",
                                color: disabled ? 'gray' : 'black'
                            } : {},
                        onFocus ? styles.textInputContainerOnFocus : {}
                    ]}
                    underlineColorAndroid="transparent"
                    editable={!disabled}
                    value={value}/>:

                <View>
                    { Platform.OS === 'ios' ?
                        <IOSPicker
                            selectedValue={value}
                            mode={"modal"}
                            onBlur={() => { onBlur(name); setOnFocus(false); }}
                            onFocus={() => { setOnFocus(true); setStatus({ ...status, failed: false }); }}
                            onValueChange={ (itemValue, itemIndex) => setFieldValue( name, itemValue ) }
                            noSelectedText={prompt}
                            textStyle={ {
                                fontFamily: Style.fontFamilyName,
                                fontSize: 14,
                                fontWeight: "normal",
                                fontStyle: "normal",
                                lineHeight: 20,
                                letterSpacing: 0,
                                color: Style.PLACEHOLDER_TEXT_COLOR
                            }}
                            style={{
                                height: 50,
                                borderRadius: 25,
                                borderStyle: "solid",
                                borderWidth: errors[name] || status.failed ? 1: 0.5,
                                borderTopWidth: errors[name] || status.failed ? 1.15: 0.5,
                                borderColor: errors[name] || status.failed ?"#ef6a6e": "rgba(83, 100, 104, 0.3)",
                                paddingHorizontal: 20,
                                color: disabled ? 'gray' : Style.PLACEHOLDER_TEXT_COLOR }
                            } >
                            { options.map( (obj, index) => <Picker.Item key={index} label={obj.label} value={obj.label} />) }
                        </IOSPicker> :
                        <View
                            style={{
                                height: 50,
                                borderRadius: 25,
                                borderStyle: "solid",
                                paddingHorizontal: 20,
                                borderWidth: errors[name] || status.failed ? 1: 0.5,
                                borderTopWidth: errors[name] || status.failed ? 1.15: 0.5,
                                borderColor: errors[name] || status.failed ?"#ef6a6e": "rgba(83, 100, 104, 0.3)",
                            }}>
                            <Picker
                                selectedValue={value}
                                onValueChange={ (itemValue, itemIndex) => setFieldValue( name, itemValue ) }
                                prompt={prompt}
                                mode={androidPickerMode}
                                style={{ height: 50, width: '100%' }}
                            >
                                <Picker.Item label={prompt} value={null} />
                                { options.map( (obj, index) => <Picker.Item key={index} label={obj.label} value={obj.label} />) }
                            </Picker>
                        </View>
                    }

                    { errors[name] && touched[name]  ?
                        <View style={{
                            flex: 1,
                            flexDirection: 'row',
                            alignItems: 'center',
                            justifyContent: 'flex-end',
                            height: 16,
                            marginTop: 5
                        }}>
                            <Text style={styles.errorLabel}>{ errors[name] }</Text>
                            <View style={{ paddingLeft: 5, marginRight: 15 }}>
                                <Image source={ require('./res/error.png') }
                                       style={{ height: 14, width: 14 }}/>
                            </View>
                        </View>: <View />
                    }
                </View>
            }

        </View>
    );
}

PickerInput.propTypes = {
    disabled: PropTypes.bool,
    field: PropTypes.shape({
        name: PropTypes.string.isRequired,
        onBlur: PropTypes.func.isRequired,
        onChange: PropTypes.func.isRequired,
        value: PropTypes.string,
    }).isRequired,
    form: PropTypes.shape({
        errors: PropTypes.object.isRequired,
        touched: PropTypes.object.isRequired,
    }).isRequired
};

PickerInput.defaultProps = {
    disabled: false,
};

export default PickerInput;
