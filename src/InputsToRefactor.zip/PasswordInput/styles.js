import { StyleSheet } from 'react-native';
import Style from "../style";


const styles = StyleSheet.create({
    container: {
        alignSelf: 'stretch',
        paddingHorizontal: 2,
        minHeight: Platform.OS === "android" ? 82 : 90
    },
    textInputLabel: {
        fontFamily: Style.fontFamilyName,
        fontSize: 16,
        fontWeight: "bold",
        fontStyle: "normal",
        lineHeight: 20,
        letterSpacing: 0,
        color: Style.TEXT,
        paddingLeft: 20
    },
    pwdTextInput: {
        flex: 1,
        height: 50,
        backgroundColor: "#FFFFFF",
        paddingHorizontal: 20,
        paddingVertical: 15,
    },
    pwdInputContainer: {
        backgroundColor: '#FFFFFF',
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        height: 50,
        padding: 10,
        alignSelf: 'stretch',
        borderStyle: "solid",
        borderWidth: 0.5,
        borderColor: "#4c536468",
        overflow: 'hidden',
        shadowColor: "#332f4a55",
        shadowRadius: 7,
        shadowOpacity: .5,
        shadowOffset : { width: 0, height: 1},
        borderRadius: 25,
    },
    pwdInputContainerOnFocus: {
        borderStyle: "solid",
        borderWidth: 1,
        borderColor: Style.HIGHLIGHT
    },
    pwdAdviceWrapper: {
        borderRadius: 25,
        backgroundColor: "#FFF",
    },
    pwdAdviceWrapperShadow: {
        shadowColor: "rgb(25,0,0)",
        shadowRadius: 10,
        shadowOpacity: .19,
        shadowOffset : { width: 0, height: 5 },
        elevation: 5
    },
    inputRightIconTouchableContainer: {
        width: 40, height: 40,
        justifyContent: 'center',
    },
    inputRightIcon: {
        width: 18,
        height: 10,
        marginRight: 20
    },
    required: {
        fontFamily: Style.FONT_FAMILY_NAME,
        fontSize: 16,
        fontWeight: "bold",
        fontStyle: "normal",
        lineHeight: 20,
        letterSpacing: 0,
        color: Style.PRIMARY_LIGHTER
    },
    errorLabel: {
        fontFamily: Style.fontFamilyName,
        fontSize: 12,
        fontWeight: "normal",
        fontStyle: "normal",
        lineHeight: 16,
        letterSpacing: 0,
        textAlign: "right",
        color: Style.ERROR
    },
    validationRulesContainer: {
        marginTop: 15,
        marginBottom: 20,
    },
    validationRulesWrapper: {
        marginLeft:15,
        height: 30,
        flexDirection: 'row',
        alignContent: 'center'
    },
    validationImage: {
        height: 30,
        width: 30,
        marginRight: 3
    },
    validationText: {
        fontFamily: Style.fontFamilyName,
        fontSize: 12,
        fontWeight: "normal",
        fontStyle: "normal",
        lineHeight: 30,
        letterSpacing: 0,
        color: Style.PLACEHOLDER_TEXT_COLOR
    }
});

export default styles;
