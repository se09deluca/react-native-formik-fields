import React, {useState} from 'react';
import {Image, Text, TextInput, TouchableOpacity, View} from 'react-native';
import styles from './styles';
import PropTypes from 'prop-types';
import * as Style from "../style";

export function PMP_PasswordInput({
                                      field: {
                                          name,
                                          onBlur,
                                          onChange,
                                          value,
                                      },
                                      form: {
                                          errors,
                                          touched,
                                          status = {},
                                          setStatus
                                      },
                                      label,
                                      showAdvice = false,
                                      isRequired = false,
                                      disabled = false,
                                      autoCorrect = false,
                                      autoCompleteType = 'off',
                                      placeholder = ''
                                  }) {

    const [ securePasswordEntry, setSecurePasswordEntry ] = useState(true );
    const [ areAdvicesVisible, setAdviceVisibility ] = useState(false);
    const [ iconName, setIconName ] = useState('eye');
    const [ onFocus, setOnFocus ] = useState(false);

    const [ leastOneLower, setLowerCase ] = useState(false);
    const [ leastOneUpper, setUpperCase ] = useState(false);
    const [ leastOneNumber, setOneNumber ] = useState(false);
    const [ leastEightChar, setEightChar ] = useState(false);

    let success = require('./res/done.png');
    let fail = require('./res/fail.png');


    const checkCustomValidity = (password) => {

        setLowerCase(/[a-z]/.test(password));
        setUpperCase(/[A-Z]/.test(password));
        setOneNumber(/\d/.test(password));
        setEightChar(password.length >= 8);

    };

    return (

        <View style={styles.container}>
            <Text style={styles.textInputLabel}>{label}&nbsp;{ isRequired? <Text style={styles.required}>*</Text>: null }</Text>

            { !showAdvice ?
                <View>
                    <View style={[
                        styles.pwdInputContainer,

                        (errors[name] && touched[name]) || status.failed ?
                            {
                                borderWidth: 1,
                                borderColor: "#ef6a6e",
                                color: disabled ? 'gray' : 'black'
                            } : {},
                        onFocus ? styles.pwdInputContainerOnFocus : {}
                    ]}>
                        <TextInput
                            style={styles.pwdTextInput}
                            underlineColorAndroid="transparent"
                            onChangeText={onChange(name)}
                            onBlur={() => { onBlur(name); setAdviceVisibility(false); setOnFocus(false);  }}
                            onFocus={() => { setAdviceVisibility(true); setOnFocus(true); setStatus({ ...status, failed: false }); }}
                            editable={!disabled}
                            value={value}
                            selectTextOnFocus={!disabled}
                            autoCorrect={autoCorrect}
                            autoCompleteType={ autoCompleteType }
                            textContentType={'none'}
                            placeholder={placeholder}
                            secureTextEntry={securePasswordEntry}/>

                        <TouchableOpacity
                            style={styles.goBackTouchable}
                            onPress={() => {
                                setSecurePasswordEntry(!securePasswordEntry);
                                setIconName(iconName === 'eye' ? 'eye-slash' : 'eye');
                            }} >
                            <Image source={ iconName === 'eye' ? require('./res/eye.png') : require('./res/eye-closed.png') }
                                   style={styles.inputRightIcon}/>
                        </TouchableOpacity>

                    </View>
                </View>:
                <View style={[styles.pwdAdviceWrapper, areAdvicesVisible ? styles.pwdAdviceWrapperShadow: {}]}>

                    <View style={[
                        styles.pwdInputContainer,
                        (errors[name] && touched[name]) || status.failed ?
                            {
                                borderWidth: 1,
                                borderColor: Style.ERROR,
                                color: disabled ? 'gray' : 'black'
                            } : {},
                        onFocus ? styles.pwdInputContainerOnFocus : {}
                    ]}>
                        <TextInput
                            style={styles.pwdTextInput}
                            underlineColorAndroid="transparent"
                            onChangeText={onChange(name)}
                            onChange={(e) => {checkCustomValidity(e.nativeEvent.text)}}
                            onBlur={() => { onBlur(name); setAdviceVisibility(false); setOnFocus(false); }}
                            onFocus={() => { setAdviceVisibility(true); setOnFocus(true); setStatus({ ...status, failed: false }); }}
                            editable={!disabled}
                            value={value}
                            selectTextOnFocus={!disabled}
                            textContentType={'none'}
                            placeholder={placeholder}
                            placeholdertextColor={Style.PLACEHOLDER_TEXT_COLOR}
                            selectionColor={Style.HIGHLIGHT}
                            secureTextEntry={securePasswordEntry}/>

                        <TouchableOpacity
                            style={styles.inputRightIconTouchableContainer}
                            onPress={() => {
                                setSecurePasswordEntry(!securePasswordEntry);
                                setIconName(iconName === 'eye' ? 'eye-slash' : 'eye');
                            }} >
                            <Image source={ iconName === 'eye' ? require('./res/eye.png') : require('./res/eye-closed.png') }
                                   style={styles.inputRightIcon}/>
                        </TouchableOpacity>
                    </View>

                    { areAdvicesVisible ?
                        <View  style={ styles.validationRulesContainer }>
                            <View style={ styles.validationRulesWrapper }>
                                <Image source={ leastOneUpper ? success : fail }
                                       style={ styles.validationImage }/>
                                <Text style={ styles.validationText }>
                                    Almeno 1 lettera maiuscola
                                </Text>
                            </View>
                            <View style={ styles.validationRulesWrapper }>
                                <Image source={ leastOneLower ? success : fail }
                                       style={ styles.validationImage }/>
                                <Text style={ styles.validationText }>
                                    Almeno 1 lettera minuscola
                                </Text>
                            </View>
                            <View style={ styles.validationRulesWrapper }>
                                <Image source={ leastOneNumber ? success : fail }
                                       style={ styles.validationImage }/>
                                <Text style={ styles.validationText }>
                                    Almeno 1 numero
                                </Text>
                            </View>
                            <View style={ styles.validationRulesWrapper }>
                                <Image source={ leastEightChar ? success : fail }
                                       style={ styles.validationImage }/>
                                <Text style={ styles.validationText }>
                                    Almeno 8 caratteri
                                </Text>
                            </View>
                        </View> : null }

                    {/*errors[name] && touched[name] && <Text style={styles.errorLabel}>{errors[name]}</Text>*/}

                </View>

            }
            {
                errors[name] && touched[name]  ?
                    <View style={{
                        flex: 1,
                        flexDirection: 'row',
                        justifyContent: 'flex-end',
                        alignItems: 'center',
                        marginTop: 15
                    }}>
                        <View style={{ justifyContent: 'flex-end', maxWidth: "80%" }}>
                            <Text style={ styles.errorLabel }>{errors[name]}</Text>
                        </View>
                        <View style={{ paddingLeft: 5, marginRight: 15 }}>
                            <Image source={require('./res/error.png')}
                                   style={{ height: 14, width: 14 }}/>
                        </View>
                    </View>: <View style={{
                        flex: 1,
                        alignItems: 'center',
                        height: 16,
                        marginTop: 5
                    }} />
            }

        </View>
    );
}

PMP_PasswordInput.propTypes = {
    disabled: PropTypes.bool,
    field: PropTypes.shape({
        name: PropTypes.string.isRequired,
        onBlur: PropTypes.func.isRequired,
        onChange: PropTypes.func.isRequired,
        value: PropTypes.string,
    }).isRequired,
    form: PropTypes.shape({
        errors: PropTypes.object.isRequired,
        touched: PropTypes.object.isRequired,
    }).isRequired,
};

PMP_PasswordInput.defaultProps = {
    disabled: false,
};
