import React, {useEffect, useState} from 'react';
import {Image, Text, TextInput, TouchableOpacity, View} from 'react-native';
import DateTimePicker from 'react-native-modal-datetime-picker';
import PropTypes from 'prop-types';
import moment from "moment";
import 'moment/locale/it';
import styles from './styles';


moment.subtractThreeYear = function addRealMonth(d) {
    let fm = moment(d).subtract(3, 'Y');
    let fmEnd = moment(fm).endOf('month');
    return d.date() !== fm.date() && fm.isSame(fmEnd.format('YYYY-MM-DD')) ? fm.add(1, 'd') : fm;
};

moment.addNineMonth = function addRealMonth(d) {
    let fm = moment(d).add(9, 'M');
    let fmEnd = moment(fm).endOf('month');
    return d.date() !== fm.date() && fm.isSame(fmEnd.format('YYYY-MM-DD')) ? fm.add(1, 'd') : fm;
};

let pastThreeYear = moment.subtractThreeYear(moment()).toISOString();
let pastThreeYearValidation = moment.subtractThreeYear(moment()).subtract(1, 'days').toISOString();
let fromNowNineMonths = moment.addNineMonth(moment()).toISOString();
let fromNowNineMonthsValidation = moment.addNineMonth(moment()).add(1, 'days').toISOString();

export const MINIMUM_DATE = {
    //TIMESTAMP: '1893456000',
    //UNIX_TIME: '01 Jan 2016 00:00:00 GMT',
    //ISO_8601: '2016-01-01T00:00:00+00:00',
    ISO_8601: pastThreeYear,
    ISO_8601_VALIDATION: pastThreeYearValidation
};

export const MAXIMUM_DATE = {
    //TIMESTAMP: '1893456000',
    //UNIX_TIME: '01 Jan 2021 00:00:00 GMT',
    //ISO_8601: '2021-12-31T00:00:00+00:00',
    ISO_8601: fromNowNineMonths,
    ISO_8601_VALIDATION: fromNowNineMonthsValidation
};

export function PMP_DatePicker({
                                   field: {
                                       name,
                                       onBlur,
                                       onChange,
                                       value,
                                   },
                                   form: {
                                       errors,
                                       touched,
                                       status = {},
                                       setStatus
                                   },
                                   setFieldValue,
                                   label = '',
                                   placeholder = '',
                                   isRequired = true,
                                   disabled = false,
                                   minimumDate,
                                   maximumDate
                               }) {

    const [ selectedDate, setSelectedDate ] = useState('');
    const [ readableDate, setReadableDate ] = useState('');
    const [ isDateTimePickerVisible, setDateTimePickerVisibility ] = useState(false);

    const handleDatePickerConfirm = (date) => {

        moment.locale('it');

        let ISODate = date.toISOString();

        setSelectedDate( ISODate );

        setReadableDate( moment( date, moment.ISO_8601 ).format('LL') );

        setFieldValue( name, ISODate );

        setDateTimePickerVisibility( false );
    };

    const handleDatePickerCancel = () => {
        setDateTimePickerVisibility( false );
    };

    useEffect(() => {

        if (value) {

            setReadableDate( moment(value, moment.ISO_8601).format('LL') );
            setSelectedDate( moment(value, moment.ISO_8601).toISOString() );
        }

    }, []);

    return (
        <View style={styles.container}>
            <Text style={styles.textInputLabel}>{label}&nbsp;{ isRequired? <Text style={styles.required}>*</Text>: null }</Text>

            <TouchableOpacity
                onPress={() => { setDateTimePickerVisibility(true); setStatus({ ...status, failed: false });  }}
                style={[
                    styles.datePickerInputContainer,
                    (errors[name] && touched[name]) || status.failed ?
                        {
                            borderWidth: 1,
                            borderColor: "#ef6a6e"
                        } : {}
                ]}>

                <TextInput
                    style={[ styles.datePickerTextInput, { color: disabled ? 'gray' : 'black' } ]}
                    value={readableDate}
                    editable={false}
                    onTouchStart={()=> { setDateTimePickerVisibility(true); setStatus({ ...status, failed: false });  } }
                    onChangeText={onChange(name)}
                    onBlur={onBlur(name)}
                    placeholder={placeholder}
                    underlineColorAndroid="transparent"
                />

                <View style={styles.inputRightIconTouchableContainer}>
                    <Image source={ require('./res/calendar.png') }
                           style={styles.inputRightIcon}/>
                </View>

            </TouchableOpacity>
            {
                errors[name] && touched[name] ?
                    <View style={{
                        flex: 1,
                        flexDirection: 'row',
                        alignItems: 'center',
                        justifyContent: 'flex-end',
                        height: 16,
                        marginTop: 5
                    }}>
                        <Text style={styles.errorLabel}>{errors[name]}</Text>
                        <View style={{ paddingLeft: 5, marginRight: 15 }}>
                            <Image source={require('./res/error.png')}
                                   style={{ height: 14, width: 14 }}/>
                        </View>
                    </View>: <View style={{
                        flex: 1,
                        flexDirection: 'row',
                        alignItems: 'center',
                        justifyContent: 'flex-end',
                        height: 16,
                        marginTop: 5
                    }} />
            }

            <DateTimePicker
                isVisible={isDateTimePickerVisible}
                onConfirm={handleDatePickerConfirm}
                onCancel={handleDatePickerCancel}
                mode={'date'}
                datePickerModeAndroid={'calendar'}
                minimumDate={ minimumDate !== undefined ?  new Date(moment(minimumDate, moment.ISO_8601).toISOString()) : new Date(MINIMUM_DATE.ISO_8601) }
                maximumDate={ maximumDate !== undefined ?  new Date(moment(maximumDate, moment.ISO_8601).toISOString()) : new Date(MAXIMUM_DATE.ISO_8601) }
                date={ selectedDate === '' ? new Date(): new Date(selectedDate) }
                confirmTextIOS={'Conferma'}
                cancelTextIOS={'Indietro'}
                hideTitleContainerIOS={false}
                headerTextIOS={'Seleziona una data'}
            />
        </View>
    );
}


PMP_DatePicker.propTypes = {
    field: PropTypes.shape({
        name: PropTypes.string.isRequired,
        onBlur: PropTypes.func.isRequired,
        onChange: PropTypes.func.isRequired,
        value: PropTypes.string,
    }).isRequired,
    form: PropTypes.shape({
        errors: PropTypes.object.isRequired,
        touched: PropTypes.object.isRequired,
    }).isRequired,
};

export default PMP_DatePicker;
