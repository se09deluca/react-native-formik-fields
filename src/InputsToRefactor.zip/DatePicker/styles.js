import { StyleSheet } from 'react-native';
import Style from "../style";


const styles = StyleSheet.create({
    container: {
        alignSelf: 'stretch',
        minHeight: Platform.OS === "android" ? 82 : 90
    },
    textInputLabel: {
        fontFamily: Style.fontFamilyName,
        fontSize: 16,
        fontWeight: "bold",
        fontStyle: "normal",
        lineHeight: 20,
        letterSpacing: 0,
        color: Style.PLACEHOLDER_TEXT_COLOR,
        paddingLeft: 20
    },
    datePickerTextInput: {
        flex: 1,
        height: 50,
        backgroundColor: "#FFFFFF",
        paddingLeft: 10,
        paddingRight: 20,
        paddingVertical: 15,
        color: Style.PLACEHOLDER_TEXT_COLOR
    },
    datePickerInputContainer: {
        backgroundColor: '#FFFFFF',
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        height: 50,
        padding: 10,
        alignSelf: 'stretch',
        borderStyle: "solid",
        borderWidth: 0.5,
        borderColor: "#4c536468",
        overflow: 'hidden',
        shadowColor: "#332f4a55",
        shadowRadius: 30,
        shadowOpacity: 1,
        shadowOffset : { width: 0, height: 1},
        borderRadius: 25
    },
    datePickerInputContainerOnFocus: {
        borderStyle: "solid",
        borderWidth: 1,
        borderColor: Style.HIGHLIGHT
    },
    datePickerAdviceWrapper: {
        borderRadius: 25,
        backgroundColor: "#FFF",
        overflow: 'hidden',
        shadowColor: "rgba(25,0,0,0.19)",
        shadowRadius: 30,
        shadowOpacity: 1,
        shadowOffset : { width: 0, height: 10},
    },
    inputRightIconTouchableContainer: {
        width: 40, height: 40,
        justifyContent: 'center',
    },
    inputRightIcon: {
        width: 21,
        height: 20,
        marginRight: 20
    },
    required: {
        fontFamily: Style.fontFamilyName,
        fontSize: 16,
        fontWeight: "bold",
        fontStyle: "normal",
        lineHeight: 20,
        letterSpacing: 0,
        color: Style.PRIMARY
    },
    errorLabel: {
        fontFamily: Style.fontFamilyName,
        fontSize: 12,
        fontWeight: "normal",
        fontStyle: "normal",
        lineHeight: 16,
        letterSpacing: 0,
        textAlign: "right",
        color: Style.ERROR
    },
    validationRuleContainer: {
        marginLeft:15,
        height: 30,
        flexDirection: 'row',
        alignContent: 'center'
    },
    validationImage: {
        height: 30,
        width: 30,
        marginRight: 3
    },
    validationText: {
        fontFamily: Style.fontFamilyName,
        fontSize: 12,
        fontWeight: "normal",
        fontStyle: "normal",
        lineHeight: 30,
        letterSpacing: 0,
        color: Style.PLACEHOLDER_TEXT_COLOR
    }
});

export default styles;
